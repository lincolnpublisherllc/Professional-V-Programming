Automate the process to run on a schedule using Julia tasks.
Outcome: A robust, reusable pipeline ready for enterprise deployment.
