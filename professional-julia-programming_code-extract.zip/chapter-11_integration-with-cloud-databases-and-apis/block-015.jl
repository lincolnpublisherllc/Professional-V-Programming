payload = JSON.json(Dict("title"=>"Hello", "body"=>"World", "userId"=>1))
HTTP.post("https://jsonplaceholder.typicode.com/posts", ["Content-Type"=>"application/json"], payload)
