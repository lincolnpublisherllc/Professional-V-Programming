Fetch data from a public API using HTTP.jl.
