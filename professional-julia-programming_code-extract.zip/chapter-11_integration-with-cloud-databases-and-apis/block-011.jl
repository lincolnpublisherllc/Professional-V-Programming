# Query documents
for doc in find(collection, Dict("age"=>Dict("\$gt"=>20)))
    println(doc)
end
Use Case: Store unstructured or semi-structured data for AI applications, logs, or JSON-heavy workflows.
