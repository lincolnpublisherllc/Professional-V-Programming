# Insert a document
insert_one(collection, Dict("name"=>"Bob", "age"=>25))
