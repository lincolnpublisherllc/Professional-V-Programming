client = GraphQLClient.Client("https://api.spacex.land/graphql/")
query = GraphQLClient.query("query { launchesPast(limit: 3) { mission_name launch_date_utc } }")
result = GraphQLClient.execute(client, query)
println(result)
