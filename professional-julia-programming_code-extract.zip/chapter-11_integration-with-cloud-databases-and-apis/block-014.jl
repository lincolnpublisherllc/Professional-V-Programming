for user in data
    println("Name: ", user["name"], ", Email: ", user["email"])
end
