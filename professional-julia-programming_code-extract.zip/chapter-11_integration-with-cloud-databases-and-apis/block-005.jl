result = LibPQ.execute(conn, "SELECT * FROM users")
for row in result
    println(row)
end
