s3 = S3Client(region="us-east-1", aws_access_key_id="AKIA...", aws_secret_access_key="...")
put_object(s3, "my-bucket", "data.json", "local_file.json")
GCP and Azure: Use REST APIs or Python integration (PyCall.jl) for cloud service SDKs.
