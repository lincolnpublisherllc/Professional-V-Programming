client = MongoClient("mongodb://localhost:27017")
db = get_database(client, "testdb")
collection = get_collection(db, "users")
