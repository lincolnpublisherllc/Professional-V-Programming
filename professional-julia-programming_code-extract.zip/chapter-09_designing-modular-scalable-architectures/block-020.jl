using Pkg
Pkg.generate("MyScientificPackage")
