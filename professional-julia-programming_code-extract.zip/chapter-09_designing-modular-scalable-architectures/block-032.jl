Objective: Design a reusable Julia package with clear interfaces for future team use.
