5.2 Layered Architecture for Scientific and Data Applications
