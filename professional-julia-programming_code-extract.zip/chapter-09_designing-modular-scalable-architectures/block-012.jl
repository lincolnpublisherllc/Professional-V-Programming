# Example: Simple Layered Scientific App
module DataLayer
export fetch_data
fetch_data() = rand(100, 3)
end
