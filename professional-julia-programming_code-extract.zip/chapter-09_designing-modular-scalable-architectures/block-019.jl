fetch(ds::CSVSource) = readdlm(ds.filepath, ',')
