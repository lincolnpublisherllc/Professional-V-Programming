module Config
mutable struct ConfigManager
    db_url::String
end
