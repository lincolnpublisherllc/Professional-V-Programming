println(analyze_data(() -> rand(100,3)))
