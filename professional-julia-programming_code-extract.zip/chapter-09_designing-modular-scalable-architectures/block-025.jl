const INSTANCE = ConfigManager("localhost:5432")
end
