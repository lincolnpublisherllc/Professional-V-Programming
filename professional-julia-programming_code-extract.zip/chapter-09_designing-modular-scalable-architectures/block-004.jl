add(x, y) = x + y
multiply(x, y) = x * y
