Add unit tests for each module.
