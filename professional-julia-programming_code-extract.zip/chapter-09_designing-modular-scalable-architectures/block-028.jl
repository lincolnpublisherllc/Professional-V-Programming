mutable struct Subject
    observers::Vector{Function}
    state::Int
end
