module BusinessLogic
using ..DataLayer
export compute_statistics
compute_statistics() = mean(fetch_data(), dims=1)
end
