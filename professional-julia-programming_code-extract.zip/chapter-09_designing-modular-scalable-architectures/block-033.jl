Define abstract types and interfaces for core components.
Structure code using modular layers (data, logic, presentation).
