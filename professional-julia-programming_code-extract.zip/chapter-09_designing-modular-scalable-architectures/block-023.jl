5.4 Design Patterns for Professional Applications
