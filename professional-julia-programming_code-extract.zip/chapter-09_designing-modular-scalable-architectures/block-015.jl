function analyze_data(fetch_fn)
    data = fetch_fn()
    return mean(data, dims=1)
end
