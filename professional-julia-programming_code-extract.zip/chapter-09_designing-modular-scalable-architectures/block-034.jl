Document usage examples for end-users.
