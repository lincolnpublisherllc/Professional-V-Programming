using .MathUtils
println(add(3, 4))  # 7
