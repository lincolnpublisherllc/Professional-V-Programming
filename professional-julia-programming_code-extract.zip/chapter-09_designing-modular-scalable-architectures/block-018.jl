struct CSVSource <: DataSource
    filepath::String
end
