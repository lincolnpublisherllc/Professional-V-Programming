module Presentation
using ..BusinessLogic
println("Mean values: ", compute_statistics())
end
