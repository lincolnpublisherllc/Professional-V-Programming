docker build -t julia-app .
docker run -p 8080:8080 julia-app
