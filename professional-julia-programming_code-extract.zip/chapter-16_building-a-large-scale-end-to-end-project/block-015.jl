Use Test.jl for unit tests and integration tests.
using Test
