@test sum([1,2,3]) == 6
@test iseven(4)
