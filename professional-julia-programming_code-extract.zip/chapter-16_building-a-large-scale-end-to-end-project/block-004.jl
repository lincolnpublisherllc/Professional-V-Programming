Functional Requirements: What should the system do (e.g., process data, make predictions)?
