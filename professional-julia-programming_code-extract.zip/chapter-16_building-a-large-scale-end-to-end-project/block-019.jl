global_logger(ConsoleLogger(stderr))
@info "Service started"
Include contextual data in logs for faster debugging.
