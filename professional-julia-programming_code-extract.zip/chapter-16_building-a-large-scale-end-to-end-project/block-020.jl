Ensure backward compatibility in updates, especially for public APIs.
