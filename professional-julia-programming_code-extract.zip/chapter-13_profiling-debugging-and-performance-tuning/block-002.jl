BenchmarkTools.jl provides accurate, repeatable performance measurements, accounting for compilation overhead and variability.
using BenchmarkTools
