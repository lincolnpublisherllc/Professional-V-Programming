@btime map(x -> x^2, 1:10_000)  # Check allocations
