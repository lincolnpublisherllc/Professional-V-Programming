Profile with Flux.jl built-in tools for training bottlenecks.
