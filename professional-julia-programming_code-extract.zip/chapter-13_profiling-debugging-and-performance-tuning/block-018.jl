Distribute tasks to threads or workers for CPU-bound computations.
using Base.Threads
