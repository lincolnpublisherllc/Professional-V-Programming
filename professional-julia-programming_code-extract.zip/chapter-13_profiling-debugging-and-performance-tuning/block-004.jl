@btime slow_sum(10_000)
