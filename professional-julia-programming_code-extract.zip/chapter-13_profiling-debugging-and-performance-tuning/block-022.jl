Objective: Conduct a full end-to-end performance audit of a Julia service.
