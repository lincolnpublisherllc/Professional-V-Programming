Outcome: A faster, memory-efficient simulation ready for production.
