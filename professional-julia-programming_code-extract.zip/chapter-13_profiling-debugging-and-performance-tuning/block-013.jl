9.2.2 Logging for Debugging
