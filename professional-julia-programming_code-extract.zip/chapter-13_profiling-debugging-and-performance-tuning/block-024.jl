Validate that optimizations do not alter service correctness.
