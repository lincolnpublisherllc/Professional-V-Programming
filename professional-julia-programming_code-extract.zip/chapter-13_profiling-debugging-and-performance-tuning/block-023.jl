Identify functions or modules responsible for most CPU/memory usage.
