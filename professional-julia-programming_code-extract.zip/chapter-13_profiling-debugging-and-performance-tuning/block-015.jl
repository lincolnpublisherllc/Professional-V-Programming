function sum_squares!(arr)
    s = 0.0
    @simd for x in arr
        s += x^2
    end
    return s
end
