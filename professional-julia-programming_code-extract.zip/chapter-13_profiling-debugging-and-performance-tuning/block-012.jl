@enter slow_sum(10_000)
