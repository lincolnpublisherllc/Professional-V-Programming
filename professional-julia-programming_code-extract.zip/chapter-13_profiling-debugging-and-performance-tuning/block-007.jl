Profile.clear()
@profile slow_sum(10_000)
Profile.print()
