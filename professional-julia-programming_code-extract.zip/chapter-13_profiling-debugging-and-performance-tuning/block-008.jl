Look for hotspots—functions consuming disproportionate time.
Combine with visualization tools (ProfileView.jl) for more clarity.
