Using mutable structures for in-place updates.
