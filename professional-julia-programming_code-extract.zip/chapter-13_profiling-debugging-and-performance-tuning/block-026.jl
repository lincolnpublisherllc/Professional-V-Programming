Mini-projects and challenges give hands-on experience with end-to-end performance engineering in Julia.
