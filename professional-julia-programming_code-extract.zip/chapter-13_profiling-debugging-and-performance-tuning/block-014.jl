Remote logging: Send logs to centralized systems for multi-node applications.
