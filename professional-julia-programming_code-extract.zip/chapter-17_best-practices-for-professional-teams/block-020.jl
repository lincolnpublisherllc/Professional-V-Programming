Add tests for new features or fixes.
