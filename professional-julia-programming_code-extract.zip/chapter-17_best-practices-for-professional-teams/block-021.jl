julia -e 'using Lint; Lint.lint("src")'
