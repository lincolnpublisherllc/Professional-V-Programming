# Returns
- The mean of the numbers in the array.
"""
function calculate_mean(arr::Vector{T}) where T
    return sum(arr) / length(arr)
end
Tools: Use Documenter.jl to automatically generate documentation for packages.
