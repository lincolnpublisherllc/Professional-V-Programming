Calculate the mean of a vector of numbers.
