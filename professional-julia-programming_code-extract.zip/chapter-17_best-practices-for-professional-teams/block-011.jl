Forking Workflow: Suitable for open-source projects where external contributors work on forks.
