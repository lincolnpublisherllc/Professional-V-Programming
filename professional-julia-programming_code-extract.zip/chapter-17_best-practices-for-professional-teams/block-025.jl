Perform a code review for an existing Julia codebase.
