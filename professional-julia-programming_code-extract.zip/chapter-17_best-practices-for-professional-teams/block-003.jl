Consistent naming conventions for variables, functions, and types (e.g., snake_case for variables and CamelCase for types).
