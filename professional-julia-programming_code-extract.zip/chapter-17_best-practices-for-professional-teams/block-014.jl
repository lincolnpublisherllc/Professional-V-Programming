13.3.1 Advanced Strategies for Continuous Integration
