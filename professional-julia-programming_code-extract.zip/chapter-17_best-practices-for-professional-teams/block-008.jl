Utilize JuliaFormatter.jl for consistent code formatting.
