Proper docstrings for all exported functions and types.
"""
    calculate_mean(arr::Vector{T}) -> Float64
