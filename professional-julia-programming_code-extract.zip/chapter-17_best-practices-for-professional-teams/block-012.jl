Function length and complexity: Limit function size to ensure they do one thing well.
