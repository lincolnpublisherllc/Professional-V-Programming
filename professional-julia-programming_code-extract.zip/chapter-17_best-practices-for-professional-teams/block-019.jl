@test sum([1, 2, 3]) == 6
@test length([1, 2, 3]) == 3
