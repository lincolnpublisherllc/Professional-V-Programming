Install dependencies (using Pkg).
