Define the coding standards and documentation guidelines for the team.
Set up a GitHub repository for the project.
