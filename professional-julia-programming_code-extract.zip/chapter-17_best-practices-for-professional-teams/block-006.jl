# Arguments
- arr: A vector of numbers (T).
