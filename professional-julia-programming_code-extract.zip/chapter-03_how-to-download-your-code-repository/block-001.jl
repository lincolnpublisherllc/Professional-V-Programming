Look for the button that says Download ZIP.
