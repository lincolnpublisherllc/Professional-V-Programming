The repository is meant for practice and learning, but you can freely edit or expand the scripts for your own games.
