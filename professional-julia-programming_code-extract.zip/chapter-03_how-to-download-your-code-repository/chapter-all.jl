Look for the button that says Download ZIP.

# ------

The repository is meant for practice and learning, but you can freely edit or expand the scripts for your own games.

# ------
