server = @async begin
    sock = Sockets.listen(8080)
    while true
        client = Sockets.accept(sock)
        @async Sockets.write(client, "Hello, Julia!\n")
    end
end
6.3.2 Channels for Communication
Channels enable producer-consumer patterns for asynchronous tasks.
ch = Channel(10)
@async for i in 1:5
    put!(ch, i)
end
