Implement Monte Carlo simulation using parallel loops.
