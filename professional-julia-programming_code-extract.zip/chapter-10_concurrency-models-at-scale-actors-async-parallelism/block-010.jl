mutable struct Actor
    mailbox::Channel
    state::Int
end
