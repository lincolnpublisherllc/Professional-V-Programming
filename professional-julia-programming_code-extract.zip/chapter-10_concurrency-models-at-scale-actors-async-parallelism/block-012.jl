actor = spawn_actor(0)
put!(actor.mailbox, 5)
put!(actor.mailbox, 10)
put!(actor.mailbox, :stop)
