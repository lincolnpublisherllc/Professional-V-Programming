Julia supports lightweight tasks via @async and Channels for cooperative concurrency.
ch = Channel(10)  # Buffer size 10
