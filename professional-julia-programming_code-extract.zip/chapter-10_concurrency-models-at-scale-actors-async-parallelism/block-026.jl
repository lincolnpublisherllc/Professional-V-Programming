Objective: Optimize an existing I/O-bound task using async programming and actor patterns.
