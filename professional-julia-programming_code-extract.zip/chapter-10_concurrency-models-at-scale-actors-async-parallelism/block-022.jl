r = @spawnat 2 sum(rand(10^6))
fetch(r)  # Get result from worker 2
