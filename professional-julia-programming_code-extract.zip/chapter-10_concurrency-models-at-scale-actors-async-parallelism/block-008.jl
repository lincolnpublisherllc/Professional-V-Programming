Avoid false sharing and excessive locking for performance-critical loops.
