arr = rand(1:100, 10^6)
println("Sum: ", parallel_sum(arr))
