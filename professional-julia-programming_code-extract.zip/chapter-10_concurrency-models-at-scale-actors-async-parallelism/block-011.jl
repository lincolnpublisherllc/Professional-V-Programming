function spawn_actor(init_state)
    mailbox = Channel{Any}(32)
    actor = Actor(mailbox, init_state)
    @async begin
        while true
            msg = take!(mailbox)
            if msg == :stop
                break
            elseif msg isa Int
                actor.state += msg
                println("Updated state: ", actor.state)
            end
        end
    end
    return actor
end
