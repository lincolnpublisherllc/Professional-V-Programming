The actor model abstracts concurrency into independent entities communicating via message passing, which is excellent for scalable systems.
