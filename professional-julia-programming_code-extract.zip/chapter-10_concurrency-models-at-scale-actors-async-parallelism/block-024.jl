Objective: Simulate π estimation using Monte Carlo method in parallel across multiple workers.
