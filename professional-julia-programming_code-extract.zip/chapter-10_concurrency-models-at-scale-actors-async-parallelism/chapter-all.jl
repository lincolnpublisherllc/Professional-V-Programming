Julia’s threading model allows simultaneous execution of code on multiple CPU cores, improving computation speed for parallelizable tasks.

# ------

using Base.Threads

# ------

function parallel_sum(arr)
    s = Threads.Atomic{Int}(0)
    Threads.@threads for i in 1:length(arr)
        s[] += arr[i]
    end
    return s[]
end

# ------

arr = rand(1:100, 10^6)
println("Sum: ", parallel_sum(arr))

# ------

Julia supports lightweight tasks via @async and Channels for cooperative concurrency.
ch = Channel(10)  # Buffer size 10

# ------

@async begin
    for i in 1:10
        put!(ch, i^2)
    end
end

# ------

for _ in 1:10
    println("Received: ", take!(ch))
end
Ideal for overlapping computations and I/O, without blocking the main thread.

# ------

Avoid false sharing and excessive locking for performance-critical loops.

# ------

The actor model abstracts concurrency into independent entities communicating via message passing, which is excellent for scalable systems.

# ------

mutable struct Actor
    mailbox::Channel
    state::Int
end

# ------

function spawn_actor(init_state)
    mailbox = Channel{Any}(32)
    actor = Actor(mailbox, init_state)
    @async begin
        while true
            msg = take!(mailbox)
            if msg == :stop
                break
            elseif msg isa Int
                actor.state += msg
                println("Updated state: ", actor.state)
            end
        end
    end
    return actor
end

# ------

actor = spawn_actor(0)
put!(actor.mailbox, 5)
put!(actor.mailbox, 10)
put!(actor.mailbox, :stop)

# ------

Non-blocking I/O allows applications to remain responsive while performing external operations such as network requests, file reads, or database queries.

# ------

using Sockets

# ------

server = @async begin
    sock = Sockets.listen(8080)
    while true
        client = Sockets.accept(sock)
        @async Sockets.write(client, "Hello, Julia!\n")
    end
end
6.3.2 Channels for Communication
Channels enable producer-consumer patterns for asynchronous tasks.
ch = Channel(10)
@async for i in 1:5
    put!(ch, i)
end

# ------

for _ in 1:5
    println("Processed: ", take!(ch))
end

# ------

Combine async I/O, actors, and channels for highly responsive applications.

# ------

Julia’s Distributed module enables multi-node computation for CPU-intensive or large-scale tasks.

# ------

using Distributed
addprocs(4)  # Add 4 worker processes

# ------

@everywhere function square(x)
    return x^2
end

# ------

results = @distributed (vcat) for i in 1:10
    square(i)
end
println(results)

# ------

r = @spawnat 2 sum(rand(10^6))
fetch(r)  # Get result from worker 2

# ------

addprocs([("192.168.1.10", 2), ("192.168.1.11", 2)])

# ------

Objective: Simulate π estimation using Monte Carlo method in parallel across multiple workers.

# ------

Implement Monte Carlo simulation using parallel loops.

# ------

Objective: Optimize an existing I/O-bound task using async programming and actor patterns.

# ------

Refactor code using @async, Channels, or actors for non-blocking execution.

# ------

Document design choices for team review.
Outcome:
Demonstrates mastery of advanced concurrency patterns, preparing developers for enterprise-level system design.

# ------

Tasks and channels provide cooperative concurrency, suitable for overlapping I/O and computation.
Actors encapsulate state and behavior, enabling message-passing concurrency for scalable systems.

# ------

Distributed computing leverages multi-node clusters for large-scale, compute-intensive workflows.

# ------

This chapter equips readers with enterprise-grade concurrency skills, setting the foundation for performance tuning, large-scale systems, and domain-specific applications in subsequent chapters.

# ------
