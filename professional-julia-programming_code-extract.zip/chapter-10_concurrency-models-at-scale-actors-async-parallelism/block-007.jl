for _ in 1:10
    println("Received: ", take!(ch))
end
Ideal for overlapping computations and I/O, without blocking the main thread.
