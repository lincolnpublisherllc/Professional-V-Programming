for _ in 1:5
    println("Processed: ", take!(ch))
end
