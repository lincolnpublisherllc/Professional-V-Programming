results = @distributed (vcat) for i in 1:10
    square(i)
end
println(results)
