jobs:
  test:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      - name: Set up Julia
        uses: julia-actions/setup-julia@v1
        with:
          version: '1.9'
      - name: Install Dependencies
        run: julia --project=. -e 'using Pkg; Pkg.instantiate()'
      - name: Run Tests
        run: julia --project=. -e 'using Pkg; Pkg.test()'
