Variable explorer for memory monitoring.
