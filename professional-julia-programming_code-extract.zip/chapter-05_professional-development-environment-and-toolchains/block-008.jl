OhMyREPL.jl for syntax highlighting and multi-line editing.
Revise.jl for live code reloading during iterative development.
