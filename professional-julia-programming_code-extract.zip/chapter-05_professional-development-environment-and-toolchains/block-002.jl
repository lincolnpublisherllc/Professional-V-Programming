1.1 Setting Up Julia for Enterprise Development
