build:
    julia scripts/build.jl
test:
    julia scripts/test.jl
