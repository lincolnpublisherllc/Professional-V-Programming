julia --version
