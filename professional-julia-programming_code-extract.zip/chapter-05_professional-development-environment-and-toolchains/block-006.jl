using Pkg
Pkg.activate("MyEnterpriseProject")
Pkg.instantiate()
