julia scripts/build.jl
julia scripts/test.jl
