using Pkg
Pkg.activate("MyEnterpriseProject")
