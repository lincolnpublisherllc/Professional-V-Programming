15.4 Strategic Considerations for Long-Term Projects
