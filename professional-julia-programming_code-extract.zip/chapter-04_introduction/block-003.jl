Design scalable architectures for scientific computing, AI, and finance.
