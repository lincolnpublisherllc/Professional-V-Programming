Macros in Julia begin with @ and operate on expressions (Expr), allowing compile-time code generation.
