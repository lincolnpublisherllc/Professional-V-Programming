Combined with generated functions and macros, introspection can adapt code paths for performance.
function dynamic_add(a, b)
    if typeof(a) == Int && typeof(b) == Int
        return a + b
    else
        return float(a) + float(b)
    end
end
