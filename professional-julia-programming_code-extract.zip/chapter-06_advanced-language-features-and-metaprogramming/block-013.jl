Enable multiple potential types for a variable.
function process(x::Union{Int, Float64})
    return x^2
end
