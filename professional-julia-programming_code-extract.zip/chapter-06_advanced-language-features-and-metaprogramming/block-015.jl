3 ⊕ 4  # returns 8
