Objective: Refactor an existing module to use generated functions and macros for performance gains.
