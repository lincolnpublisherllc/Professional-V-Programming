methods(sqrt)
typeof(sqrt)
