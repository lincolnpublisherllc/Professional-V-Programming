add_types(5, 10)  # returns 15
add_types(3.2, 4.8)  # returns 8.0
