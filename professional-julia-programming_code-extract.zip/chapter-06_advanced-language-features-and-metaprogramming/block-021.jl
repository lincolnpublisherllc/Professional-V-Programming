Objective: Implement a small DSL for a mathematical modeling workflow.
