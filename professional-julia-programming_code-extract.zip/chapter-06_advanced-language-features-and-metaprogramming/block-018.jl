Improves readability for domain experts.
