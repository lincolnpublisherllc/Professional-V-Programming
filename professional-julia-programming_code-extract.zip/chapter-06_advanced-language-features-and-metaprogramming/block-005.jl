Generated functions are declared using @generated and allow Julia to produce specialized code depending on compile-time type information.
