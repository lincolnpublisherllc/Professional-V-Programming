import Base: ⊕
⊕(a, b) = a + b + 1
