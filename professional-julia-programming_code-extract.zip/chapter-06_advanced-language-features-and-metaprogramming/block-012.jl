function area(s::Shape)
    s isa Circle && return π * s.radius^2
    s isa Rectangle && return s.width * s.height
end
