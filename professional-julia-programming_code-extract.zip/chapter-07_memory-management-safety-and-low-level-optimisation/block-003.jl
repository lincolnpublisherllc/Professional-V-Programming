x = 10        # stack allocation (small immutable)
y = [1, 2, 3] # heap allocation (mutable array)
Heap allocation incurs garbage collection overhead, while stack allocation is fast and deterministic.
