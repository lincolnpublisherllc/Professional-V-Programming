Use preallocated arrays for repeated operations.
Favor immutable structs for temporary data in performance-critical code.
