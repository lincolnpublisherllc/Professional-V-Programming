finalizer(x -> println("Object freed"), obj)
