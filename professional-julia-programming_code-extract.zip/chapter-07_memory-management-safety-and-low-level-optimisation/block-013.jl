ccall((:sin, "libm"), Float64, (Float64,), 1.5708) # approx π/2
