Profile the simulation using BenchmarkTools.jl and Profile.
