Julia uses heap allocation for mutable types (e.g., Array, Dict) and stack allocation for immutable small types (e.g., Int64, Float64).
