Use Array{T,1} with contiguous memory for optimal SIMD performance.
Consider StaticArrays.jl for small fixed-size arrays, minimizing heap allocations.
