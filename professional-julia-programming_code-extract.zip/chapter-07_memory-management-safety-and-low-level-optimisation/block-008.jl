arr = rand(1000, 1000)
@btime sum($arr)
