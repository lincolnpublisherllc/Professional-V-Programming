arr = [1, 2, 3, 4]
ptr = pointer(arr)
unsafe_store!(ptr, 10)
println(arr) # [10, 2, 3, 4]
