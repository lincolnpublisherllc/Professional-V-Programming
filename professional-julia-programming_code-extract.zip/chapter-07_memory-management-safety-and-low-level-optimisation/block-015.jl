a = rand(1000)
b = rand(1000)
c = a .+ b  # vectorized addition
