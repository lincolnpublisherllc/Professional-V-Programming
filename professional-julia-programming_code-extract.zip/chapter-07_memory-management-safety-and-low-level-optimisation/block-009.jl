println("Array memory usage: ", Base.summarysize(arr))
