Leverage GPU via CUDA.jl or LoopVectorization.jl for matrix-heavy computations.
