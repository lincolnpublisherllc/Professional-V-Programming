pq = PriorityQueue{String, Int}()
enqueue!(pq, "task1", 2)
enqueue!(pq, "task2", 1)
println(dequeue!(pq))  # Returns "task2"
