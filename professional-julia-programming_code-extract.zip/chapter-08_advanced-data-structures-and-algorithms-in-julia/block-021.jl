Vectorized operations outperform loops for large datasets.
