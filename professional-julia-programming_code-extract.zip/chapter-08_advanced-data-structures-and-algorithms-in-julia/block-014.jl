g = Graph(5)
add_edge!(g, 1, 2)
add_edge!(g, 2, 3)
println(vertices(g))
