Objective: Implement an optimized search algorithm for a large-scale dataset.
