sort(arr, rev=true)
