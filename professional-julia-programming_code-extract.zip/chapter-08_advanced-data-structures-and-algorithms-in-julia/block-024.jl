Objective: Build a simple recommendation engine using graphs.
