mutable struct TreeNode
    val::Int
    left::Union{TreeNode, Nothing}
    right::Union{TreeNode, Nothing}
end
