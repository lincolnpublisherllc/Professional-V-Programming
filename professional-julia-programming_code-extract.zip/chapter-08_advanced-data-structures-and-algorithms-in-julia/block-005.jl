# Fast membership test
println(3 in s)  # true
