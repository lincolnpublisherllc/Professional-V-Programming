Benchmark using BenchmarkTools.jl for datasets with thousands of nodes.
