arr = [5, 2, 9, 1]
sorted_arr = sort(arr)  # [1, 2, 5, 9]
