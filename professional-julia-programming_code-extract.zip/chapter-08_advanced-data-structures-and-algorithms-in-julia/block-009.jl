push!(s::Stack, value) = push!(s.data, value)
pop!(s::Stack) = pop!(s.data)
Use Cases: Encapsulate behavior and maintain performance for specialized operations.
