arr = sort([5, 2, 9, 1])
findfirst(==(5), arr)  # O(log n) via binary search
