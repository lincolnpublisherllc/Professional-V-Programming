dict = Dict("Alice"=>25, "Bob"=>30)
dict["Charlie"] = 28
println(dict["Alice"])  # 25
Advanced Tip: Use OrderedDict from DataStructures.jl for predictable iteration order.
