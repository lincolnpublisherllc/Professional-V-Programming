arr = rand(10^6)
@btime sort($arr)
