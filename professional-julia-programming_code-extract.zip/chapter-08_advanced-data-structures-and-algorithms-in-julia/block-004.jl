s = Set([1, 2, 3, 3, 4])
println(s)  # Output: Set([1, 2, 3, 4])
