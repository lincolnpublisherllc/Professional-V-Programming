point = (x=1.0, y=2.0)
println(point.x, ", ", point.y)
Performance Note: Tuples are stack-allocated and very memory-efficient for fixed-size elements.
