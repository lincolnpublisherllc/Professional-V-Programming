# Initial condition and time span
u0 = [1.0]
tspan = (0.0, 5.0)
