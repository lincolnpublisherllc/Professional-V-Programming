# Setup simulation for object motion
body = RigidBody([1.0, 0.0, 0.0], 0.0)  # Initial position and velocity
simulate(body)
