# Define a simple ODE: dy/dt = -2y
function f!(du, u, p, t)
    du[1] = -2 * u[1]
end
