Flux.jl is a powerful and flexible deep learning library for Julia, while MLJ.jl provides a high-level interface for machine learning workflows.
