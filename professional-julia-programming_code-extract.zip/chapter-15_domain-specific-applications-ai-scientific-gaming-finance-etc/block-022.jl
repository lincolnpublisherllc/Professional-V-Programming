# Simulate some financial data
data = DataFrame(Date=1:100, Price=rand(100))
ts_data = TimeArray(data.Date, data.Price)
