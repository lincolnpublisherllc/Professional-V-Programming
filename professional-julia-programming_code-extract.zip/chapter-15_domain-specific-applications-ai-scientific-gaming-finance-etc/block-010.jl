# Move model and data to GPU
model = model |> gpu
data = rand(Float32, 784) |> gpu
