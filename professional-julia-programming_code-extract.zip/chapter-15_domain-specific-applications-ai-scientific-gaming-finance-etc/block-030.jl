Reactive programming can be implemented using Channels and tasks.
ch = Channel(10)
@async begin
    while true
        msg = take!(ch)
        println("Event: ", msg)
    end
end
