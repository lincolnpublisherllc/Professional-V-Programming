ws = WebSocket("wss://streaming-api.com")
on_message(ws) do msg
    println("Received data: ", msg)
end
