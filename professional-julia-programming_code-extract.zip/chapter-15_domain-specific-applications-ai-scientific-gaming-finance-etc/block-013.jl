DifferentialEquations.jl allows for the simulation of differential equations in both continuous and discrete models.
using DifferentialEquations
