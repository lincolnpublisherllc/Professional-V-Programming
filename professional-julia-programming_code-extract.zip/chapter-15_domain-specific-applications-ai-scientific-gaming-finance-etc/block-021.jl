TimeSeries.jl and DataFrames.jl provide robust tools for analyzing financial time-series data.
using DataFrames, TimeSeries
