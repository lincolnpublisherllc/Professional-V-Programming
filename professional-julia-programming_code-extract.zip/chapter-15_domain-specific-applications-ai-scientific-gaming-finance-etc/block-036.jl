Use Flux.jl or MLJ.jl for training models.
Implement a real-time component using @async and WebSockets.jl.
