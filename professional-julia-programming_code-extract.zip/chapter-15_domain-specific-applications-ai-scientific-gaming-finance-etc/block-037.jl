Expected Outcome:
A fully functional simulation that applies domain-specific techniques to solve practical problems, optimized for performance.
