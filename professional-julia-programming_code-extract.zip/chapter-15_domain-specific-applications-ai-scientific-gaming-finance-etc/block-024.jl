JuMP.jl allows you to formulate linear and nonlinear optimization problems, ideal for portfolio optimization and risk management.
using JuMP, GLPK
