using CUDA
