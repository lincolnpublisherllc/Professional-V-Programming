# Calculate moving average
moving_avg = moving_average(ts_data, 5)
