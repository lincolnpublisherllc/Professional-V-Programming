# Define a simple neural network
model = Chain(Dense(784, 64, relu), Dense(64, 10))
