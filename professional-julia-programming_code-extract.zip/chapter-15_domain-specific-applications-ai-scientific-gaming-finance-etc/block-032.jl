RigidBodyDynamics.jl is a Julia package for simulating rigid body dynamics for games and simulations.
using RigidBodyDynamics
