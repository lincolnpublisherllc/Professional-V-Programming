# Solve the ODE
prob = ODEProblem(f!, u0, tspan)
sol = solve(prob)
