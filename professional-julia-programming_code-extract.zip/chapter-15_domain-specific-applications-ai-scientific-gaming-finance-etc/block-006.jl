# Define a loss function
loss(x, y) = crossentropy(model(x), y)
