# Training loop
for epoch in 1:10
    for (x, y) in training_data
        gs = gradient(() -> loss(x, y), params(model))
        update!(optimizer, params(model), gs)
    end
end
