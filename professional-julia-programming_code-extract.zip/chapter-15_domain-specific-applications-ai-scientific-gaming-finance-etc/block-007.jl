# Use an optimizer
optimizer = ADAM()
