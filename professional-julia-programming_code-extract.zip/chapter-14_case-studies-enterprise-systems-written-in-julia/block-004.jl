using LinearAlgebra
A = rand(1000, 1000)
B = rand(1000, 1000)
C = A * B
Julia’s performance is on par with C and Fortran, making it a powerful tool for scientific research.
