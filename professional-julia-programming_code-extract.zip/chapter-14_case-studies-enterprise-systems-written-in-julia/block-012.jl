Challenge: Implement a reinforcement learning agent for autonomous vehicles or robotics.
