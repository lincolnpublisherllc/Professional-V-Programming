Julia is heavily used in computational physics for simulations of particle dynamics, fluid flow, and quantum mechanics.
