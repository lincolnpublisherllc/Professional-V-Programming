Challenge: Calculate portfolio risk (Value-at-Risk, expected shortfall) using large financial datasets.
