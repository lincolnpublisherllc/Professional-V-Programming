Model Portfolio Data: Create a function that simulates financial assets using random data (or public financial datasets).
