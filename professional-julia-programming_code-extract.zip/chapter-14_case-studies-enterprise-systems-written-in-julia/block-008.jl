function monte_carlo_simulation(n)
    results = randn(n)
    return mean(results), std(results)
end
