Challenge: Simulate particle interactions using large-scale matrix operations.
