Audit packages for recent vulnerabilities.
Prefer well-maintained, widely-used packages for critical functionality.
