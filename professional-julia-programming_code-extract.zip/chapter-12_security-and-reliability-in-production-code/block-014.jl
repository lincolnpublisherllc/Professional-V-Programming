Implement retries for transient failures (e.g., network errors).
