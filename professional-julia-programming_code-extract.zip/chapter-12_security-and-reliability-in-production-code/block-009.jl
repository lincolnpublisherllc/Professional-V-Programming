logger = ConsoleLogger(stderr, Logging.Info)
with_logger(logger) do
    @info "Starting data pipeline..."
    try
        error("Simulated failure")
    catch e
        @error "Pipeline error" exception=(e, catch_backtrace())
    end
end
