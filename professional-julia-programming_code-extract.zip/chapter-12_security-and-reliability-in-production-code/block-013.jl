Implement alerts for critical failures.
