api_key = ENV["MY_API_KEY"]  # Securely access API key
