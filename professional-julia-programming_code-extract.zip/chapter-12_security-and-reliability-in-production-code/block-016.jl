Implement input sanitization for all API parameters.
