try
    result = 10 / 0
catch e
    println("Error caught: ", e)
end
