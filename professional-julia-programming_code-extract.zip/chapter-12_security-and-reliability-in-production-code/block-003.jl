user_input = sanitize_user_input("<script>alert('hack')</script>")
println(user_input)  # Safe string output
