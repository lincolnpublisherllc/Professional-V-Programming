function sanitize_user_input(name::AbstractString)
    cleaned = replace(name, r"[^a-zA-Z0-9 ]" => "")
    return cleaned
end
