To receive your materials, please send an email to info@lincolnpublishers.us with the subject line Companion Resources for [Professional Julia Programming]. Include your name and proof of purchase (order number or screenshot). We will reply with a link to download the files.

# ------
