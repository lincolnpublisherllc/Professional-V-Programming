Role: Design and deploy machine learning models for applications in AI, computer vision, natural language processing, or predictive analytics.
