Role: Use Julia for data analysis, visualization, and statistical modeling in sectors like finance, healthcare, retail, and marketing.
