Skills: DifferentialEquations.jl, Optim.jl, Plots.jl, PyCall.jl for multi-language integration.
