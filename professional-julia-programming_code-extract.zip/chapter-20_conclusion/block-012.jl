DifferentialEquations.jl GitHub: Engage with the development of Julia’s differential equation solvers and related tools for scientific computing.
