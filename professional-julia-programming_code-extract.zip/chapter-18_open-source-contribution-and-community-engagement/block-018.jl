### **14.3.3 Mentoring and Community Engagement**
- **Mentor new users** or contributors by answering questions on **Discourse**, **Slack**, or **StackOverflow**.
- Become a **core contributor** or **maintainer** to help guide the direction of Julia libraries and packages.
