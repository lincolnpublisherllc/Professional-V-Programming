Contributions can come in many forms—bug fixes, new features, documentation improvements, or example code. Contributing to an open-source project is not just about writing code but also about creating value for the wider community.
14.2.1 Best Practices for Contributing Code
