**Objective:** Contribute to an existing **open-source Julia project** by submitting a **patch** or **documentation update**.
