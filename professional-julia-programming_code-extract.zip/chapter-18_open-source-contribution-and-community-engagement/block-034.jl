**Outcome:**  
You will demonstrate **leadership and organizational skills** while managing **real-world open-source contributions**, gaining recognition as a **key contributor** within the Julia community.
