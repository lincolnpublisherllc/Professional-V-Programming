@test add_numbers(2, 3) == 5
Unit Tests: Always include unit tests for new functionality. Many Julia projects use Test.jl for automated testing.
@test sum([1, 2, 3]) == 6
