# Arguments
- `a::Int`: The first number.
- `b::Int`: The second number.
