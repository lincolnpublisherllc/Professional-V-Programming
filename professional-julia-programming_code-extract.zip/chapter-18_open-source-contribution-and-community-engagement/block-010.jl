# Returns
The sum of `a` and `b`.
