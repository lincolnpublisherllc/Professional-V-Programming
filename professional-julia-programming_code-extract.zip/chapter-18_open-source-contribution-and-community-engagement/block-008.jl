Adds two numbers together.
