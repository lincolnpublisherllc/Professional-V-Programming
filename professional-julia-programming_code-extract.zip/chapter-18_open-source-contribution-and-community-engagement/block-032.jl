**Objective:** Lead a **community project**, manage **contributions**, and merge updates professionally.
