# Example
```julia
add_numbers(2, 3)  # Returns 5
"""
function add_numbers(a::Int, b::Int)
return a + b
end
- Regularly update documentation as part of the development process.
