DifferentialEquations.jl: A framework for solving differential equations, widely used in scientific simulations.
