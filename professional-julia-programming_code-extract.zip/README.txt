# Code Extraction Summary
This archive contains Julia code extracted chapter-by-chapter from the provided DOCX.
Heuristics used: paragraph styles named like 'Code'/'Preformatted', monospaced fonts, and Julia cues like 'julia>' or keywords.
Each chapter has a folder with numbered code blocks (.jl) and a `chapter-all.jl` concatenation.
An `index.csv` at the root lists block locations and metadata.
